﻿namespace Proyecto1_Progra_2
{
    class Estudiante
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public int Nivel { get; set; }
        public CarreraTecnica CarreraTecnica { get; set; }
        public string EncargadoLegal { get; set; }


        public Estudiante(string nombre, int edad, string direccion, string telefono, int nivel,string encargadoLegal)
        {
            Nombre = nombre;
            Edad = edad;
            Direccion = direccion;
            Telefono = telefono;
            Nivel = nivel;
            EncargadoLegal = encargadoLegal;

        }
    }
}

