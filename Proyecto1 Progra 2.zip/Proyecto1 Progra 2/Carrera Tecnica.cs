﻿namespace Proyecto1_Progra_2
{
    class CarreraTecnica
    {
        public string Nombre { get; set; }
        public int Duracion { get; set; }

        public CarreraTecnica(string nombre, int duracion)
        {
            Nombre = nombre;
            Duracion = duracion;
        }
    }
}
