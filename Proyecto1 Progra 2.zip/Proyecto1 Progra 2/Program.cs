﻿using System;
using System.Collections.Generic;

namespace Proyecto1_Progra_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Bienvenido al sistema de matrícula del Colegio Técnico Profesional San Pedro de Barva");

            List<Estudiante> estudiantes = new List<Estudiante>();

            List<CarreraTecnica> carrerasTecnicas = new List<CarreraTecnica>()
            {
                new CarreraTecnica("Informática en Redes", 3),
                new CarreraTecnica("Contabilidad", 3),
                new CarreraTecnica("Ejecutivo", 3),
                new CarreraTecnica("Electrónica Industrial", 3)
            };


            while (true)
            {
                Console.WriteLine("Menú principal:");
                Console.WriteLine("1. Registrar estudiante");
                Console.WriteLine("2. Matricular estudiante");
                Console.WriteLine("3. Ver estudiantes matriculados");
                Console.WriteLine("4. Salir");

                int opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        RegistrarEstudiante(estudiantes);
                        break;
                    case 2:
                        MatricularEstudiante(estudiantes, carrerasTecnicas);
                        break;
                    case 3:
                        VerEstudiantesMatriculados(estudiantes);
                        break;
                    case 4:
                        Console.WriteLine("Saliendo del sistema...");
                        return;
                    default:
                        Console.WriteLine("Opción inválida. Por favor, intente nuevamente.");
                        break;
                }
            }
        }

        static void RegistrarEstudiante(List<Estudiante> estudiantes)
        {
            Console.WriteLine("Registro estudiante");
            Console.WriteLine("Ingrese el nombre del estudiante:");
            string nombre = Console.ReadLine();
            Console.WriteLine("Ingrese la edad del estudiante:");
            int edad = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la dirección del estudiante:");
            string direccion = Console.ReadLine();
            Console.WriteLine("Ingrese el teléfono del estudiante:");
            string telefono = Console.ReadLine();
            Console.WriteLine("Ingrese el nivel: ");
            int nivel = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el nombre del encargado legal:");
            string encargadoLegal = Console.ReadLine();

            Estudiante estudiante = new Estudiante(nombre, edad, direccion, telefono, nivel, encargadoLegal);
            estudiantes.Add(estudiante);

            Console.WriteLine("Estudiante registrado con éxito.");
        }

        static void MatricularEstudiante(List<Estudiante> estudiantes, List<CarreraTecnica> carrerasTecnicas)
        {
            Console.WriteLine("Matricular estudiante:");
            Console.WriteLine("Seleccione el estudiante:");

            for (int i = 0; i < estudiantes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {estudiantes[i].Nombre}");
            }

            int indiceEstudiante = int.Parse(Console.ReadLine()) - 1;
            Estudiante estudiante = estudiantes[indiceEstudiante];

            Console.WriteLine("Seleccione la carrera técnica:");
            for (int i = 0; i < carrerasTecnicas.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {carrerasTecnicas[i].Nombre} ({carrerasTecnicas[i].Duracion} años)");
            }

            int indiceCarrera = int.Parse(Console.ReadLine()) - 1;
            CarreraTecnica carrera = carrerasTecnicas[indiceCarrera];

            estudiante.CarreraTecnica = carrera;
            Console.WriteLine("Estudiante matriculado con éxito.");
        }

        static void VerEstudiantesMatriculados(List<Estudiante> estudiantes)
        {
            Console.WriteLine("Estudiantes matriculados:");
            foreach (Estudiante estudiante in estudiantes)
            {
                Console.WriteLine($"Nombre: {estudiante.Nombre}, Edad: {estudiante.Edad}, Dirección: {estudiante.Direccion}, Teléfono: {estudiante.Telefono}");
                Console.WriteLine($"Nivel: {estudiante.Nivel}");
                Console.WriteLine($"Carrera técnica: {estudiante.CarreraTecnica.Nombre} ({estudiante.CarreraTecnica.Duracion} años)");
                Console.WriteLine($"Encargado legal: {estudiante.EncargadoLegal}");
                Console.WriteLine();
            }
        }

    }
}


